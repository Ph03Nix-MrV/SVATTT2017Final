#!/usr/bin/env python
from flag import FLAG
from random import randint

assert len(FLAG) == 72
size = 9


def transform(byte, n):
    """
    Wanna see something wierd? Here it is 
    """
    return (byte >> n) | ((byte & (((3 * (n * 2 + 1) & 1) << n) - (7 * (n * 2 + 1) & 1))) << (size - n))


def process(FLAG):
    flag = int(FLAG.encode('hex'), 16)
    flag = bin(flag).lstrip('0b')
    FLAG = []
    for i in range(0, len(flag), size):
        FLAG.append(int(flag[i:i + size], 2))
    return FLAG


def enlarge(number):
    return (number + 0x636f)


FLAG = process(FLAG)

for i in range(len(FLAG)):
    FLAG[i] = transform(FLAG[i], i % size)
    FLAG[i] = transform(FLAG[i], (i + 3) % size)

FLAG = map(lambda x: enlarge(x), FLAG)


def generate_equation(n, x, y):
    """
    Generate equation at degree n 
    Remember, ^ is power operation, not XOR 
    """
    result = 0
    equation = []
    for i in range(n + 1):
        coeff = randint(1337, 13337)
        if i == 0:
            temp = '{}*x^{}'.format(coeff, n)
            temp_res = coeff * x**(n)
        elif n - i == 0:
            temp = '{}*y^{}'.format(coeff, n)
            temp_res = coeff * y**(n)
        else:
            temp = '{}*x^{}*y^{}'.format(coeff, n - i, i)
            temp_res = coeff * x**(n - i) * y**(i)

        if i != 0:
            if i * 1337 % 2 == 0:
                equation.append(' + ')
                result = result + temp_res
            else:
                equation.append(' - ')
                result = result - temp_res
        else:
            result += temp_res

        equation.append(temp)

    equation.append(' == {}\n\n'.format(result))
    return equation


def encrypt(flag):
    with open('solveme.txt', 'w') as f:
        for i in range(0, len(FLAG), 2):
            n = randint(13, 37)
            equation = generate_equation(n, FLAG[i], FLAG[i + 1])
            equation = ''.join(equation)
            f.write(equation)


encrypt(FLAG)
